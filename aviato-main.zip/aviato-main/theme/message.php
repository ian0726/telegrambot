<?php
if (isset($_SESSION['message'])):
    ?>
    <div class="alertPart mt-50">
        <div class="alert alert-warning alert-common alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
            <i class="tf-ion-alert-circled"></i>
            <strong>注意！</strong>
            <?= $_SESSION['message']; ?>
        </div>
    </div>
    <?php
    unset($_SESSION['message']);
endif;
?>