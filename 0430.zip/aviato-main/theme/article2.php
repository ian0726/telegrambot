<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>行前訓練管理系統</title>

	<!-- Mobile Specific Metas
  ================================================== -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Construction Html5 Template">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
	<meta name="author" content="Themefisher">
	<meta name="generator" content="Themefisher Constra HTML Template v1.0">

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="images/boticon.jpg" />

	<!-- Themefisher Icon font -->
	<link rel="stylesheet" href="plugins/themefisher-font/style.css">
	<!-- bootstrap.min css -->
	<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">

	<!-- Animate css -->
	<link rel="stylesheet" href="plugins/animate/animate.css">
	<!-- Slick Carousel -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/slick/slick-theme.css">

	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<!--table-->
	<script src='//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js'></script>
	<script src='//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js'></script>
	<link href='//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css' rel='stylesheet'>
	</link>

</head>

<body id="body">
	<!-- Start Top Header Bar -->
	<section class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-xs-12 col-sm-4">
					<div class="contact-number">
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Site Logo -->
					<div class="logo text-center">
						<a href="index2.php">
							<!-- replace logo here -->
							<svg width="264px" height="35px" viewBox="0 0 220 35" version="1.1"
								xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
								<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
									font-size="33" font-family="AustinBold, Austin" font-weight="bold">
									<g id="Group" transform="translate(-108.000000, -297.000000)" fill="#000000">
										<text id="AVIATO">
											<tspan x="84.94" y="325">行前訓練管理系統</tspan>
										</text>
									</g>
								</g>
							</svg>
						</a>
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Cart -->
					<ul class="top-menu text-right list-inline">


						<!-- Search -->
						<!-- / Search -->

						<!-- Languages -->
						<li class="dropdown ">
							<form method="post" action="logoutcheck.php">
								<button type="submit" name="logout"
									style="border: 0ch; background-color: white;">登出</button>
							</form>
						</li><!-- / Languages -->

					</ul><!-- / .nav .navbar-nav .navbar-right -->
				</div>
			</div>
		</div>
	</section><!-- End Top Header Bar -->


	<!-- Main Menu Section -->
	<section class="menu">
		<nav class="navbar navigation">
			<div class="container">
				<div class="navbar-header">
					<h2 class="menu-title">Main Menu</h2>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
						aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

				</div><!-- / .navbar-header -->

				<!-- Navbar Links -->
				<div id="navbar" class="navbar-collapse collapse text-center">
					<ul class="nav navbar-nav">
						<li class="dropdown ">
							<a href="index2.php">首頁</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">相關資訊 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">訓練資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="teaching2.php">教學</a></li>
										<li><a href="notice2.php">基本注意事項</a></li>
										<li><a href="video2.php">相關教學影片</a></li>
										<li><a href="article2.php">相關教學文章</a></li>
									</ul>
									<ul>
										<li role="separator" class="divider"></li>
										<li class="dropdown-header">更多資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="contact3.php">聯絡資訊</a></li>
									</ul>
								</div>
							</div>
						</li>
						<li class="dropdown ">
							<a href="scores.php">學生表現</a>
						</li>
						<li class="dropdown ">
							<a href="chatlog.php">訊息記錄</a>
						</li>
						<li class="dropdown ">
							<a href="https://docs.google.com/forms/d/16KjKc-m5kaDNM54hte5msX0IiZjTR8fsrA7r2VTGKWA/edit#responses"
								target="_blank">教學日誌回報</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">使用回饋 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">類別</li>
										<li role="separator" class="divider"></li>
										<li><a href="feedback.php">整體功能</a></li>
										<li><a href="feedback2.php">使用流暢度</a></li>
										<li><a href="feedback3.php">機器人評分</a></li>
										<li><a href="feedback4.php">其他</a></li>
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<!--/.navbar-collapse -->
			</div><!-- / .container -->
		</nav>
	</section>
	<section class="page-header">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="content">
						<h1 class="page-name">訓練資訊</h1>
						<ol class="breadcrumb">
							<li><a href="index2.php">首頁</a></li>
							<li class="active">相關教學文章</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="user-dashboard page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul class="list-inline dashboard-menu text-center">
						<li><a href="teaching2.php">教學</a></li>
						<li><a href="notice2.php">基本注意事項</a></li>
						<li><a href="video2.php">相關教學影片</a></li>
						<li><a class="active" href="article2.php">相關教學文章</a></li>
					</ul>
					<?php
					include('message.php');
					?>
					<br>
					<div class="block billing-details">
						<ul class="text-right">
							<button class='btn btn-primary btn-sm' data-toggle='modal'
								data-target='#product-modal'>新增</button>
						</ul>
					</div>
					<div class="dashboard-wrapper user-dashboard">
						<div class="table-responsive">
							<table class="table text-center" id="myTable">
								<thead>
									<tr>
										<th></th>
										<th class="text-center">網址</th>
										<th class="text-center">點擊前往</th>
										<th class="text-center">編輯</th>
										<th class="text-center">刪除</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$servername = "sql12.freemysqlhosting.net";
									$username = "sql12603359";
									$password = "7fSf6yVhTL";
									$dbname = "sql12603359";
									$conn = new mysqli($servername, $username, $password, $dbname);

									$conn->set_charset("utf8mb4");

									// 檢查連線是否成功
									if ($conn->connect_error) {
										die("連線失敗: " . $conn->connect_error);
									}

									$query = "SELECT * FROM article";
									$query_run = mysqli_query($conn, $query);

									if (mysqli_num_rows($query_run) > 0) {
										foreach ($query_run as $article) {
											?>
											<tr>
												<td>
													<?= $article['id']; ?>
												</td>
												<td>
													<a href="<?= $article['url'] ?>" target="_blank"><?= $article['url'] ?></a>
												</td>
												<td>
													<a class="btn btn-default" href="<?= $article['url'] ?>" target="_blank">
														View</a>
												</td>
												<td>
													<a href="edit_article.php?id=<?= $article['id']; ?>"
														class="btn btn-success btn-sm">Edit</a>
												</td>
												<td>
													<form action="receive.php" method="POST" class="d-inline">
														<button type="submit" name="delete_article"
															value="<?= $article['id']; ?>"
															class="btn btn-danger btn-sm">Delete</button>
													</form>
												</td>
											</tr>
											<?php
										}
									} else {
										echo "<h5> No Record Found </h5>";
									}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Modal -->
	<div class="modal product-modal fade" id="product-modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<i class="tf-ion-close"></i>
		</button>
		<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-body">
					<div class="row">
						<div class="col-md-12">
							<div class="product-short-details">
								<ul class="list-inline dashboard-menu text-center">
									<h4 class="product-title">新增文章</h4>
								</ul>
								<div class="table-responsive">
									<form method="post" action="receive.php" class="checkout-form">
										<div class="form-group">
											<label for="full_name">文章網址</label>
											<input type="text" class="form-control" name="url" placeholder=""
												required="required">
										</div>
										<div class="form-group text-center">
											<button class="btn btn-primary" name="save_article"
												type="submit">新增</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- /.modal -->
	<script>
		$('#myTable').DataTable();
	</script>
	<footer class="footer section text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

				</div>
			</div>
		</div>
	</footer>
	<!-- 
	Essential Scripts
	=====================================-->

	<!-- Main jQuery -->
	<script src="plugins/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap 3.1 -->
	<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
	<!-- Bootstrap Touchpin -->
	<script src="plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
	<!-- Instagram Feed Js -->
	<script src="plugins/instafeed/instafeed.min.js"></script>
	<!-- Video Lightbox Plugin -->
	<script src="plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
	<!-- Count Down Js -->
	<script src="plugins/syo-timer/build/jquery.syotimer.min.js"></script>

	<!-- slick Carousel -->
	<script src="plugins/slick/slick.min.js"></script>
	<script src="plugins/slick/slick-animation.min.js"></script>

	<!-- Google Mapl -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
	<script type="text/javascript" src="plugins/google-map/gmap.js"></script>

	<!-- Main Js File -->
	<script src="js/script.js"></script>



</body>

</html>