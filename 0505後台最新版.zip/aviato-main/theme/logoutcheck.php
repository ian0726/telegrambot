<?php
session_start();
if (isset($_POST['logout'])) { // 當按下登出按鈕時
   ?>
   <script>
      if (confirm("確定要登出嗎？")) { // 顯示確認對話框，如果按下確認
         <?php
         session_unset(); // 清除 session
         session_destroy(); // 刪除 session
         ?>
         parent.location.href = "login.php"; // 跳轉回登入頁面
      } else { // 如果按下取消
         parent.location.href = "index2.php"; // 重新導向回首頁
      }
   </script>
   <?php
}
?>