<?php
session_start();
?>
<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="en">

<head>

	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>行前訓練管理系統</title>

	<!-- Mobile Specific Metas
  ================================================== -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Construction Html5 Template">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
	<meta name="author" content="Themefisher">
	<meta name="generator" content="Themefisher Constra HTML Template v1.0">

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="IMG.JPG" />

	<!-- Themefisher Icon font -->
	<link rel="stylesheet" href="plugins/themefisher-font/style.css">
	<!-- bootstrap.min css -->
	<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">

	<!-- Animate css -->
	<link rel="stylesheet" href="plugins/animate/animate.css">
	<!-- Slick Carousel -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/slick/slick-theme.css">

	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<!--table-->
	<script src='//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js'></script>
	<script src='//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js'></script>
	<link href='//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css' rel='stylesheet'>
	</link>

</head>

<body id="body">
	<!-- Start Top Header Bar -->
	<section class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-xs-12 col-sm-4">
					<div class="contact-number">
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Site Logo -->
					<div class="logo text-center">
						<a href="index2.php">
							<!-- replace logo here -->
							<svg width="264px" height="35px" viewBox="0 0 220 35" version="1.1"
								xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
								<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
									font-size="33" font-family="AustinBold, Austin" font-weight="bold">
									<g id="Group" transform="translate(-108.000000, -297.000000)" fill="#000000">
										<text id="AVIATO">
											<tspan x="84.94" y="325">行前訓練管理系統</tspan>
										</text>
									</g>
								</g>
							</svg>
						</a>
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Cart -->
					<ul class="top-menu text-right list-inline">


						<!-- Search -->
						<!-- / Search -->
						<li class="dropdown ">
							<a href="https://www.facebook.com/ihopetw/?locale=zh_TW" target="_blank">
								<i class="tf-ion-social-facebook"></i>
							</a>
						</li>
						<!-- Languages -->
						<li class="dropdown ">
							<form method="post" action="logoutcheck.php">
								<button type="submit" name="logout"
									style="border: 0ch; background-color: white;">登出</button>
							</form>
						</li><!-- / Languages -->

					</ul><!-- / .nav .navbar-nav .navbar-right -->
				</div>
			</div>
		</div>
	</section><!-- End Top Header Bar -->


	<!-- Main Menu Section -->
	<section class="menu">
		<nav class="navbar navigation">
			<div class="container">
				<div class="navbar-header">
					<h2 class="menu-title">Main Menu</h2>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
						aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

				</div><!-- / .navbar-header -->

				<!-- Navbar Links -->
				<div id="navbar" class="navbar-collapse collapse text-center">
					<ul class="nav navbar-nav">
						<li class="dropdown ">
							<a href="index2.php">首頁</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">相關資訊 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">訓練資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="teaching2.php">教學</a></li>
										<li><a href="notice2.php">基本注意事項</a></li>
										<li><a href="video2.php">相關教學影片</a></li>
										<li><a href="article2.php">相關教學文章</a></li>
									</ul>
									<ul>
										<li role="separator" class="divider"></li>
										<li class="dropdown-header">更多資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="contact3.php">聯絡資訊</a></li>
									</ul>
								</div>
							</div>
						</li>
						<li class="dropdown ">
							<a href="scores.php">學生表現</a>
						</li>
						<li class="dropdown ">
							<a href="chatlog.php">訊息記錄</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">教學日誌 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<!-- Basic -->
									<ul>
										<li class="dropdown-header">類別</li>
										<li role="separator" class="divider"></li>
										<li><a href="form.php">依日期查看</a></li>
										<li><a href="form2.php">依姓名查看</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="https://docs.google.com/forms/d/1cAMPIaOeNrpwywCYwVhaiqAyJc5w_cJSzmFVpSFwebQ/edit#responses"
												target="_blank">Google表單</a></li>
									</ul>
								</div><!-- / .row -->
							</div><!-- / .dropdown-menu -->
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">使用回饋 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">類別</li>
										<li role="separator" class="divider"></li>
										<li><a href="feedback.php">整體功能</a></li>
										<li><a href="feedback2.php">使用流暢度</a></li>
										<li><a href="feedback3.php">機器人評分</a></li>
										<li><a href="feedback4.php">其他</a></li>
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<!--/.navbar-collapse -->
			</div><!-- / .container -->
		</nav>
	</section>
	<section class="page-header">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="content">
						<h1 class="page-name">訊息記錄</h1>
						<ol class="breadcrumb">
							<li><a href="index2.php">首頁</a></li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="user-dashboard page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="dashboard-wrapper user-dashboard">
						<div class="table-responsive">
							<table class="table" id="myTable">
								<thead>
									<tr>
										<th>使用者</th>
										<th>訊息</th>
										<th>回覆時間</th>
									</tr>
								</thead>
								<tbody>
									<?php

									$mysqli = new mysqli("sql12.freemysqlhosting.net", "sql12603359", "7fSf6yVhTL", "sql12603359");

									if ($mysqli->connect_errno) {
										echo "Failed to connect to MySQL: " . $mysqli->connect_error;
										exit();
									}

									$mysqli->set_charset('utf8');
									$sql = "SELECT chat_id, message, sender_name, date FROM chat_log";
									if ($result = $mysqli->query($sql)) {
										// 取得每一筆資料，填入表格中
										while ($row = $result->fetch_assoc()) {
											echo "<tr>";
											echo "<td>" . $row['sender_name'] . "</td>";
											echo "<td>" . $row['message'] . "</td>";
											echo "<td>" . $row['date'] . "</td>";
											echo "</tr>";
										}

										$result->free();
									}

									$mysqli->close();
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<script>
		$('#myTable').DataTable();
	</script>
	<footer class="footer section text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

				</div>
			</div>
		</div>
	</footer>
	<!-- 
	Essential Scripts
	=====================================-->

	<!-- Main jQuery -->
	<script src="plugins/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap 3.1 -->
	<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
	<!-- Bootstrap Touchpin -->
	<script src="plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
	<!-- Instagram Feed Js -->
	<script src="plugins/instafeed/instafeed.min.js"></script>
	<!-- Video Lightbox Plugin -->
	<script src="plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
	<!-- Count Down Js -->
	<script src="plugins/syo-timer/build/jquery.syotimer.min.js"></script>

	<!-- slick Carousel -->
	<script src="plugins/slick/slick.min.js"></script>
	<script src="plugins/slick/slick-animation.min.js"></script>

	<!-- Google Mapl -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
	<script type="text/javascript" src="plugins/google-map/gmap.js"></script>

	<!-- Main Js File -->
	<script src="js/script.js"></script>



</body>

</html>