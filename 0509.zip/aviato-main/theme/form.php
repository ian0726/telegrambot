<?php
session_start();
?>
<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="en">

<head>

	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>行前訓練管理系統</title>

	<!-- Mobile Specific Metas
  ================================================== -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Construction Html5 Template">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
	<meta name="author" content="Themefisher">
	<meta name="generator" content="Themefisher Constra HTML Template v1.0">

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="IMG.JPG" />

	<!-- Themefisher Icon font -->
	<link rel="stylesheet" href="plugins/themefisher-font/style.css">
	<!-- bootstrap.min css -->
	<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">

	<!-- Animate css -->
	<link rel="stylesheet" href="plugins/animate/animate.css">
	<!-- Slick Carousel -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/slick/slick-theme.css">

	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<!--table-->
	<script src='//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js'></script>
	<script src='//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js'></script>
	<link href='//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css' rel='stylesheet'>
	</link>

</head>

<body id="body">
	<!-- Start Top Header Bar -->
	<section class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-xs-12 col-sm-4">
					<div class="contact-number">
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Site Logo -->
					<div class="logo text-center">
						<a href="index2.php">
							<!-- replace logo here -->
							<svg width="264px" height="35px" viewBox="0 0 220 35" version="1.1"
								xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
								<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
									font-size="33" font-family="AustinBold, Austin" font-weight="bold">
									<g id="Group" transform="translate(-108.000000, -297.000000)" fill="#000000">
										<text id="AVIATO">
											<tspan x="84.94" y="325">行前訓練管理系統</tspan>
										</text>
									</g>
								</g>
							</svg>
						</a>
					</div>
				</div>
				<div class="col-md-4 col-xs-12 col-sm-4">
					<!-- Cart -->
					<ul class="top-menu text-right list-inline">


						<!-- Search -->
						<!-- / Search -->
						<li class="dropdown ">
							<a href="https://www.facebook.com/ihopetw/?locale=zh_TW" target="_blank">
								<i class="tf-ion-social-facebook"></i>
							</a>
						</li>
						<!-- Languages -->
						<li class="dropdown ">
							<form method="post" action="logoutcheck.php">
								<button type="submit" name="logout"
									style="border: 0ch; background-color: white;">登出</button>
							</form>
						</li><!-- / Languages -->

					</ul><!-- / .nav .navbar-nav .navbar-right -->
				</div>
			</div>
		</div>
	</section><!-- End Top Header Bar -->


	<!-- Main Menu Section -->
	<section class="menu">
		<nav class="navbar navigation">
			<div class="container">
				<div class="navbar-header">
					<h2 class="menu-title">Main Menu</h2>
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
						aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

				</div><!-- / .navbar-header -->

				<!-- Navbar Links -->
				<div id="navbar" class="navbar-collapse collapse text-center">
					<ul class="nav navbar-nav">
						<li class="dropdown ">
							<a href="index2.php">首頁</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">相關資訊 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">訓練資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="teaching2.php">教學</a></li>
										<li><a href="notice2.php">基本注意事項</a></li>
										<li><a href="video2.php">相關教學影片</a></li>
										<li><a href="article2.php">相關教學文章</a></li>
									</ul>
									<ul>
										<li role="separator" class="divider"></li>
										<li class="dropdown-header">更多資訊</li>
										<li role="separator" class="divider"></li>
										<li><a href="contact3.php">聯絡資訊</a></li>
									</ul>
								</div>
							</div>
						</li>
						<li class="dropdown ">
							<a href="scores.php">學生表現</a>
						</li>
						<li class="dropdown ">
							<a href="chatlog.php">訊息記錄</a>
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">教學日誌 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<!-- Basic -->
									<ul>
										<li class="dropdown-header">類別</li>
										<li role="separator" class="divider"></li>
										<li><a href="form.php">依日期查看</a></li>
										<li><a href="form2.php">依姓名查看</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="https://docs.google.com/forms/d/1cAMPIaOeNrpwywCYwVhaiqAyJc5w_cJSzmFVpSFwebQ/edit#responses"
												target="_blank">Google表單</a></li>
									</ul>
								</div><!-- / .row -->
							</div><!-- / .dropdown-menu -->
						</li>
						<li class="dropdown dropdown-slide">
							<a href="#!" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
								data-delay="350" role="button" aria-haspopup="true" aria-expanded="false">使用回饋 <span
									class="tf-ion-ios-arrow-down"></span></a>
							<div class="dropdown-menu">
								<div class="row">
									<ul>
										<li class="dropdown-header">類別</li>
										<li role="separator" class="divider"></li>
										<li><a href="feedback.php">整體功能</a></li>
										<li><a href="feedback2.php">使用流暢度</a></li>
										<li><a href="feedback3.php">機器人評分</a></li>
										<li><a href="feedback4.php">其他</a></li>
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<!--/.navbar-collapse -->
			</div><!-- / .container -->
		</nav>
	</section>
	<section class="page-header">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="content">
						<h1 class="page-name">教學日誌</h1>
						<ol class="breadcrumb">
							<li><a href="index2.php">首頁</a></li>
							<li class="active">依日期查看</li>
						</ol>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="user-dashboard page-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul class="list-inline dashboard-menu text-center">
						<li><a class="active" href="form.php">日期</a></li>
						<li><a href="form2.php">個別</a></li>
					</ul>
					<br>
					<div class="table-responsive">
						<form method="POST" action="">
							請選擇要查看的日期&nbsp;
							<select name="year">
								<?php
								$current_year = date('Y');
								for ($i = $current_year - 2; $i <= $current_year; $i++) {
									echo "<option value='$i'>$i</option>";
								}
								?>
							</select>
							<select name="month">
								<option value="1">1月</option>
								<option value="2">2月</option>
								<option value="3">3月</option>
								<option value="4">4月</option>
								<option value="5">5月</option>
								<option value="6">6月</option>
								<option value="7">7月</option>
								<option value="8">8月</option>
								<option value="9">9月</option>
								<option value="10">10月</option>
								<option value="11">11月</option>
								<option value="12">12月</option>
							</select>
							<input type="submit" name="submit" value="顯示">
						</form>
						<style>
							table {
								width: 100%;
							}

							th,
							td {
								border: 1px solid black;
								text-align: center;
								height: 50px;
							}

							table {
								font-size: 20px;
							}

							.table-wrapper {
								display: flex;
								justify-content: center;
							}
						</style>
						<?php
						if (isset($_POST['submit'])) {
							$year = $_POST['year'];
							$month = $_POST['month'];

							// 取得當月第一天的星期幾和當月總天數
							$first_day_of_month = strtotime("$year-$month-01");
							$day_of_week = date('w', $first_day_of_month);
							$num_of_days_in_month = date('t', $first_day_of_month);

							// 建立表格顯示月曆
							echo "<table>";
							echo "<tr><th colspan='7'>" . $year . "年" . $month . "月</th></tr>";
							echo "<tr><th>日</th><th>一</th><th>二</th><th>三</th><th>四</th><th>五</th><th>六</th></tr>";

							// 填充空格
							echo "<tr>";
							for ($i = 0; $i < $day_of_week; $i++) {
								echo "<td></td>";
							}

							// 填充日期
							for ($day = 1; $day <= $num_of_days_in_month; $day++) {
								if ($day_of_week == 7) {
									echo "</tr><tr>";
									$day_of_week = 0;
								}
								echo "<td><a href='checkform.php?date=$year-$month-$day'>$day</a></td>";
								$day_of_week++;
							}

							// 填充空格
							for ($i = $day_of_week; $i < 7; $i++) {
								echo "<td></td>";
							}

							echo "</tr>";
							echo "</table>";
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<footer class="footer section text-center">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

				</div>
			</div>
		</div>
	</footer>
	<!-- 
	Essential Scripts
	=====================================-->

	<!-- Main jQuery -->
	<script src="plugins/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap 3.1 -->
	<script src="plugins/bootstrap/js/bootstrap.min.js"></script>
	<!-- Bootstrap Touchpin -->
	<script src="plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
	<!-- Instagram Feed Js -->
	<script src="plugins/instafeed/instafeed.min.js"></script>
	<!-- Video Lightbox Plugin -->
	<script src="plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
	<!-- Count Down Js -->
	<script src="plugins/syo-timer/build/jquery.syotimer.min.js"></script>

	<!-- slick Carousel -->
	<script src="plugins/slick/slick.min.js"></script>
	<script src="plugins/slick/slick-animation.min.js"></script>

	<!-- Google Mapl -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
	<script type="text/javascript" src="plugins/google-map/gmap.js"></script>

	<!-- Main Js File -->
	<script src="js/script.js"></script>



</body>

</html>