<?php
session_start();
$host = "sql12.freemysqlhosting.net";
$username = "sql12603359";
$password = "7fSf6yVhTL";
$database = "sql12603359";
$query = "SET NAMES 'UTF8'";

$conn = mysqli_connect($host, $username, $password, $database);
mysqli_query($conn, $query);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!doctype html>
<html lang="en">

<head>

    <head>

        <!-- Basic Page Needs
================================================== -->
        <meta charset="utf-8">
        <title>行前訓練管理系統</title>

        <!-- Mobile Specific Metas
================================================== -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Construction Html5 Template">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
        <meta name="author" content="Themefisher">
        <meta name="generator" content="Themefisher Constra HTML Template v1.0">

        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="IMG.JPG" />

        <!-- Themefisher Icon font -->
        <link rel="stylesheet" href="plugins/themefisher-font/style.css">
        <!-- bootstrap.min css -->
        <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">

        <!-- Animate css -->
        <link rel="stylesheet" href="plugins/animate/animate.css">
        <!-- Slick Carousel -->
        <link rel="stylesheet" href="plugins/slick/slick.css">
        <link rel="stylesheet" href="plugins/slick/slick-theme.css">

        <!-- Main Stylesheet -->
        <link rel="stylesheet" href="css/style.css">

    </head>

<body id="body">
    <!-- Start Top Header Bar -->
    <section class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-xs-12 col-sm-4">
                    <div class="contact-number">
                    </div>
                </div>
                <div class="col-md-4 col-xs-12 col-sm-4">
                    <!-- Site Logo -->
                    <div class="logo text-center">
                        <a href="index2.php">
                            <!-- replace logo here -->
                            <svg width="264px" height="35px" viewBox="0 0 220 35" version="1.1"
                                xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"
                                    font-size="33" font-family="AustinBold, Austin" font-weight="bold">
                                    <g id="Group" transform="translate(-108.000000, -297.000000)" fill="#000000">
                                        <text id="AVIATO">
                                            <tspan x="84.94" y="325">行前訓練管理系統</tspan>
                                        </text>
                                    </g>
                                </g>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Top Header Bar -->

    <section class="user-dashboard page-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul class="list-inline dashboard-menu text-center">
                        <h4>
                            查看教學日誌回報
                        </h4>
                    </ul>
                    <div class="dashboard-wrapper user-dashboard">
                        <div class="table-responsive">
                            <style>
                                table,
                                td {
                                    border: 1px solid #333;
                                }

                                thead,
                                tfoot {
                                    background-color: #333;
                                    color: #fff;
                                }
                            </style>

                            <?php

                            // 取得傳遞進來的bname值
                            $bname = $_GET['bname'];

                            // 建立 MySQL 連線
                            $conn = mysqli_connect("sql12.freemysqlhosting.net", "sql12603359", "7fSf6yVhTL", "sql12603359");
                            // 設定資料庫編碼為 utf8mb4
                            mysqli_set_charset($conn, "utf8mb4");

                            // 執行查詢語句
                            $sql = "SELECT * FROM form WHERE bname = '" . mysqli_real_escape_string($conn, $bname) . "'";
                            $result = mysqli_query($conn, $sql);

                            // 顯示表格
                            
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<table>';
                                echo '<thead>';
                                echo '<tr><th colspan="2">遠距陪讀教學日誌</th></tr>';
                                echo '</thead>';
                                echo '<tbody>';
                                echo '<tr>';
                                echo '<td>日期：' . $row['date'] . '</td>';
                                echo '<td>教室：' . $row['class'] . '</td>';
                                echo '</tr>';
                                echo '<tr>';
                                echo '<td>學童：' . $row['sname'] . '</td>';
                                echo '<td>大學伴：' . $row['bname'] . '</td>';
                                echo '</tr>';
                                echo '<tr>';
                                echo '<td>學校：' . $row['sschool'] . '</td>';
                                echo '<td>大學全名：' . $row['bschool'] . '</td>';
                                echo '</tr>';
                                echo '<tr>';
                                echo '<td>年級：' . $row['sgrade'] . '</td>';
                                echo '<td>系所全名/年級：' . $row['bgrade'] . '</td>';
                                echo '</tr>';
                                echo '</tbody>';
                                echo '</table>';
                                echo '<h5>授課內容：' . $row['teach'] . '</h5>';
                                echo '<h5>時間分配：' . $row['time'] . '</h5>';
                                echo '<h5>學童狀況：' . $row['status'] . '</h5>';
                                echo '<h5>教學心得：' . $row['experience'] . '</h5>';
                            }

                            // 釋放資源及關閉資料庫連線
                            mysqli_free_result($result);
                            mysqli_close($conn);

                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 
    Essential Scripts
    =====================================-->

    <!-- Main jQuery -->
    <script src="plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.1 -->
    <script src="plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap Touchpin -->
    <script src="plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
    <!-- Instagram Feed Js -->
    <script src="plugins/instafeed/instafeed.min.js"></script>
    <!-- Video Lightbox Plugin -->
    <script src="plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
    <!-- Count Down Js -->
    <script src="plugins/syo-timer/build/jquery.syotimer.min.js"></script>

    <!-- slick Carousel -->
    <script src="plugins/slick/slick.min.js"></script>
    <script src="plugins/slick/slick-animation.min.js"></script>

    <!-- Google Mapl -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
    <script type="text/javascript" src="plugins/google-map/gmap.js"></script>

    <!-- Main Js File -->
    <script src="js/script.js"></script>



</body>

</html>