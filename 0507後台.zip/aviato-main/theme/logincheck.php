<?php
   session_start();
   $host = "sql12.freemysqlhosting.net";
   $username = "sql12603359";
   $password = "7fSf6yVhTL";
   $database = "sql12603359";
   $query = "SET NAMES 'UTF8'";

   $conn = mysqli_connect($host, $username, $password, $database);
   $AccountName=$_POST["AccountName"];
   $password=$_POST["password"];


   //$link=mysqli_connect("sql12.freemysqlhosting.net","sql12603359","7fSf6yVhTL","sql12603359");
   $sql="SELECT * FROM account WHERE AccountName='$AccountName' AND password='$password'";
   $rs=mysqli_query($conn,$sql);
   if($record=mysqli_fetch_assoc($rs)){
      $_SESSION["AccountName"]=$record["AccountName"];
     
      header("location:index2.php");
   }else{?>
   <script> 
    alert("請確認帳號密碼");
    parent.location.href="login.php";
    </script>                 
 <?php }?>